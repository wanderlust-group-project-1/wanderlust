<?php
require_once('../app/views/layout/header.php');

require_once('../app/views/components/navbar.php');
?>



<?php require_once('../app/views/sections/hero.php');
?>

<?php require_once('../app/views/sections/about.php');
?>

<?php require_once('../app/views/sections/guide.php');
?>

<?php require_once('../app/views/sections/rental-service.php');
?>

<?php require_once('../app/views/sections/blog.php');
?>

<?php require_once('../app/views/sections/tips.php');
?>

<?php require_once('../app/views/sections/complaints.php');
?>
<!-- <h1> Home page view </h1>


<h4> Hi <?= $email ?> </h4> -->



<!-- <a href="<?= ROOT_DIR ?>/login" title="Login">Login</a>
<br>
<a href="<?= ROOT_DIR ?>/signup" title="Signup">Signup</a>
<br>
<a href="<?= ROOT_DIR ?>/logout" title="Logout">Logout</a> -->

<?php
require_once('../app/views/layout/footer.php');


?>