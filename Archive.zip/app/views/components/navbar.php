<nav class="navbar">
    <div class="logo">
        <img src="<?= ROOT_DIR ?>/assets/images/logo.png" alt="logo">
    </div>
    <ul class="nav-menu">
        <li class="nav-menu-item"><a href="#">Home</a></li>
        <li class="nav-menu-item"><a href="#">About</a></li>
        <li class="nav-menu-item"><a href="#">Guides</a></li>
        <li class="nav-menu-item"><a href="#">Rental Services</a></li>
        <li class="nav-menu-item"><a href="#">Blogs</a></li>
        <li class="nav-menu-item"><a href="#">Tips & Knowhows</a></li>
        <li class="nav-menu-item"><a href="#">Complaints</a></li>
    </ul>
    <div class="login-button"><a href="#">Login</a></div>
</nav>