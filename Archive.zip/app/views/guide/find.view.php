<?php
require_once('../app/views/layout/header.php');

require_once('../app/views/components/navbar.php');
?>



    <div class="frame4">
        <div class="div">

            <div class="div-2">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Jenny Fernando">
            </div>

            <div class="div-2">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Jenny Fernando">
            </div>

            <div class="div-2">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Jenny Fernando">
            </div>

        </div>

        <div class="div-3">

            <div class="frame-wrapper">
                <button class="search-button">Most rated</button>
            </div>

            <div class="frame-wrapper">
                <button class="search-button">Price low to high</button>
            </div>

            <div class="frame-wrapper">
                <button class="search-button">No of Tours</button>
            </div>

            <div class="frame-wrapper">
                <button class="search-button">hsgsh</button>
            </div>



            <button class="serach-button-2">Search</button>


        </div>


    </div>

    <div class="frame5">

        <div class="div">
            <text class="text-wrapper">Steve Johnson</text>
            <div class="img-1">
                <img src="<?php echo ROOT_DIR?>/assets/images/1.png" alt="">
            </div>
            <text class="text-wrapper-2">Guide</text>
        </div>

        <div class="div-2">

            <form class="div-3">

                <div class="div-4">
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Name : Jenny Fernando</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Age : 20</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Role : Customer</div>
                    </div>
                </div>

                <div class="div-4">
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Name : Jenny Fernando</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Age : 20</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Role : Customer</div>
                    </div>
                </div>

            </form>

            <button class="serach-button-2">Check availability</button>


        </div>
    </div>

    <div class="frame5">

        <div class="div">
            <text class="text-wrapper">Steve Johnson</text>
            <div class="img-1">
                <img src="<?php echo ROOT_DIR?>/assets/images/1.png" alt="">
            </div>
            <text class="text-wrapper-2">Guide</text>
        </div>

        <div class="div-2">

            <form class="div-3">

                <div class="div-4">
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Name : Jenny Fernando</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Age : 20</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Role : Customer</div>
                    </div>
                </div>

                <div class="div-4">
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Name : Jenny Fernando</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Age : 20</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Role : Customer</div>
                    </div>
                </div>

            </form>

            <button class="serach-button-2">Check availability</button>


        </div>
    </div>


    <div class="frame5">

        <div class="div">
            <text class="text-wrapper">Steve Johnson</text>
            <div class="img-1">
                <img src="<?php echo ROOT_DIR?>/assets/images/1.png" alt="">
            </div>
            <text class="text-wrapper-2">Guide</text>
        </div>

        <div class="div-2">

            <form class="div-3">

                <div class="div-4">
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Name : Jenny Fernando</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Age : 20</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Role : Customer</div>
                    </div>
                </div>

                <div class="div-4">
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Name : Jenny Fernando</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Age : 20</div>
                    </div>
                    <div class="div-wrapper">
                        <div class="text-wrapper-2">Role : Customer</div>
                    </div>
                </div>

            </form>

            <button class="serach-button-2">Check availability</button>


        </div>
    </div>


</body>

</html>