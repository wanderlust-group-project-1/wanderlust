<div class="hero">
    <div class="home-container row">
        <div class="col col-2">
            <h1 class="hero-title">Campers,</h1>
            <p class="hero-description"><b>Your Gateway to Outdoor Adventures:</b> <br>
                Gear Up & Go with Expert Guides!</p>
            <div class="section-button"><a href="#">Get Started</a></div>
        </div>
        <div class="col col-2">
            <img src="<?= ROOT_DIR ?>/assets/images/hero.png" alt="Hero Image">
        </div>

    </div>

</div>