
<html>
    <head>
        <title>Wanderlust</title>
        <link rel="stylesheet" type="text/css" href="<?=ROOT_DIR ?>/assets/css/style.css">
        <link rel="stylesheet" type="text/css" href="<?=ROOT_DIR ?>/assets/css/admin-style.css">

    </head>
<body>

