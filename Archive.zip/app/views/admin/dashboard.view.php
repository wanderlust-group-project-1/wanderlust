<?php
require_once('../app/views/admin/layout/header.php');
require_once('../app/views/admin/layout/sidebar.php');

?>


      <?php
require_once('../app/views/admin/layout/footer.php');


?>