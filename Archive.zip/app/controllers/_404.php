<?php

class _404{
    use Controller;
    public function index(){
        echo "Controller not found";
    }
}


?>