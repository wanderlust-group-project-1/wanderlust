<?php

echo "This is the index page";



?>